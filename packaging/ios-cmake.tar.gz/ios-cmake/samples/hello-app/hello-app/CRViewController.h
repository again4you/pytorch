//
//  CRViewController.h
//  hello-app
//
//  Created by Bogdan Cristea on 12/27/13.
//  Copyright (c) 2013 Bogdan Cristea. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CRViewController : UIViewController

@end
