#ifndef HELLOWORLD_H
#define HELLOWORLD_H

#include <string>

class HelloWorld
{
public:
	std::string helloWorld();
};

#endif 
