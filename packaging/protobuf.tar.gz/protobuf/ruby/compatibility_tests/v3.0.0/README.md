# Protobuf Ruby Compatibility Tests

This drectory contains a snapshot of protobuf ruby 3.0.0 unittest code and
test scripts used to verifies whether the latest version of protobuf is
still compatible with 3.0.0 generated code.
