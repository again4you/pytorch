peachpy package
===============

peachpy module
--------------

.. automodule:: peachpy.function
   :members:
   :show-inheritance:

peachpy.c module
----------------

.. automodule:: peachpy.c.types
   :members:
   :show-inheritance:

peachpy.x86_64 module
---------------------

.. automodule:: peachpy.x86_64
    :members:
    :show-inheritance:

.. automodule:: peachpy.x86_64.uarch
    :members:
    :show-inheritance:

.. automodule:: peachpy.x86_64.function
    :members:
    :show-inheritance:

.. automodule:: peachpy.x86_64.isa
    :members:
    :show-inheritance:

.. automodule:: peachpy.x86_64.registers
    :members:
    :show-inheritance:

.. automodule:: peachpy.x86_64.pseudo
    :members:

.. automodule:: peachpy.x86_64.generic
    :members:

.. automodule:: peachpy.x86_64.mmxsse
    :members:

.. automodule:: peachpy.x86_64.avx
    :members:
