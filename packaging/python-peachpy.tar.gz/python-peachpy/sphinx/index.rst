PeachPy documentation!
=======================

Contents:

.. toctree::
   :maxdepth: 4

   peachpy


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

