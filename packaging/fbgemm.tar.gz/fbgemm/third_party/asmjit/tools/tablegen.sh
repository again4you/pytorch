#!/bin/sh

node ./tablegen-x86.js
